class sliderModel{
  String? image;
  String? name;
}