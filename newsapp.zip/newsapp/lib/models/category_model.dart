class CategoryModel{
 String? categoryName;
 String? image;

}